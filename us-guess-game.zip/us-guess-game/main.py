import pandas as pd
import turtle
import turtle_creation

# Game settings
screen = turtle.Screen()
screen.setup(width= 700, height= 500)
screen.title("U.S States Game")
image = "blank_states_img.gif"
screen.addshape(image)
turtle.shape(image)

# Variables
game_on = True
correct_answers = 0
answered = []

# Retrieve Data from csv file.
data = pd.read_csv("50_states.csv")
states = data["state"].tolist()

# Main
while game_on is True and correct_answers < 50:
    for state in states:
        answer = screen.textinput("U.S States Game", "Guess a state")
        if answer is not None:
            answer = answer.title()
            answer = answer.strip()

            if answer not in states:
                print(f"You got {correct_answers} states out of 50")
                game_on = False
                break

            elif answer in states and answer not in answered:
                answered.append(answer)
                correct_answers += 1
                row = data[data["state"] == answer]
                x = float(row.get("x"))
                y = float(row.get("y"))
                unveil = turtle_creation.State(x, y)
                unveil.write(f"{answer}")
        else:
            continue

screen.exitonclick()